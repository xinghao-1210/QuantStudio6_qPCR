function [package] = read_QuantStudio6_qpcrdata(filename,ctrl_Tar,ctrl_Samp)


%%
%$Hard-code
display_Ct=false;
accepted_controls={'CphA','GAPDH','18S','GUSB','HPRT1'};
consider_only_folder=true;
NaN_is_num=true;
NaNnum=40;
%display_Ct=true;

%%

if nargin<1 || isempty(filename)
    UI_later=true;
    
    if consider_only_folder
        temp=dir;
        ind_xls_files=[];
        for n=1:length(temp)
            tempname=temp(n).name;
            len_tn=length(tempname);
            if len_tn>4
                if strcmpi(tempname((len_tn-3):(len_tn)),'.xls') ||  strcmpi(tempname((len_tn-4):(len_tn)),'.xlsx')
                    ind_xls_files=[ind_xls_files,n];
                end
            end
        end
    else
        ind_xls_files=[];
    end
    if length(ind_xls_files)==1
        dirn=pwd;
        dirn=[pwd,'\'];
        fn=temp(ind_xls_files).name;
    else
        [fn,dirn] = uigetfile('*.xls;*.xlsx','All Excel files');
    end
    filename=[dirn,fn];
else
    UI_later=false;
end
filename2save=[filename(1:(length(filename)-4))];

if exist([filename2save '.mat'])==2
    load([filename2save '.mat']);
    savelater=false;
    
    Ct_samp_by_tar=package.raw.Ct_samp_by_tar;
    SampName_list=package.raw.SampleNames;
    TarName_list=package.raw.TarNames;
else
    [dat,head,raw]=xlsread(filename,'Results','A41:AK650');
    savelater=true;
    rn=check_range_row(raw);
    
    WellPos=raw(rn,2);
    Omit=raw(rn,3);
    SampName=raw(rn,4);
    TarName=raw(rn,5);
    Ct_raw=ones(max(size(rn)),1);
    Ct_raw=-1*Ct_raw;
    for k=1:max(size(rn))
        if isa(raw{rn(k),15},'double')
            Ct_raw(k)=raw{rn(k),15};
        else
            if NaN_is_num
                Ct_raw(k)=NaNnum;
            else
                Ct_raw(k)=NaN;
            end
        end
    end
    
    
    [SampName_s1,ti]=sort(SampName);
    TarName_s1=TarName(ti);
    WellPos_s1=WellPos(ti);
    Ct_s1=Ct_raw(ti);
    Omit_s1=Omit(ti);
    
    [TarName_s2,ti2]=sort(TarName_s1);
    SampName_s2=SampName_s1(ti2);
    WellPos_s2=WellPos_s1(ti2);
    Ct_s2=Ct_s1(ti2);
    Omit_s2=Omit_s1(ti2);
    
    SampName_list=unique(SampName_s2);
    TarName_list=unique(TarName_s2);
    
    Ct_samp_by_tar=[];r=[];c=[];
    track_depth=ones(max(size(SampName_list)),max(size(TarName_list)));
    for k=1:max(size(Ct_s2))
        r=findchareq(SampName_s2{k},SampName_list);
        c=findchareq(TarName_s2{k},TarName_list);
        Ct_samp_by_tar(r,c,track_depth(r,c))=Ct_s2(k);
        track_depth(r,c)=track_depth(r,c)+1;
    end
    for a=1:size(Ct_samp_by_tar,1)
        for b=1:size(Ct_samp_by_tar,2)
            for c=1:size(Ct_samp_by_tar,3)
                if Ct_samp_by_tar(a,b,c)==0
                    Ct_samp_by_tar(a,b,c)=NaN;
                end
            end
        end
    end
    raw.Ct_samp_by_tar=Ct_samp_by_tar;
    raw.SampleNames=SampName_list;
    raw.TarNames=TarName_list;
end
if UI_later
    for n=1:length(accepted_controls)
        tempctrl_Tar_ind(n)=findchareq(accepted_controls{n},TarName_list);        
    end
    validtempctrl_Tar_ind=tempctrl_Tar_ind<=length(TarName_list);
    if sum(validtempctrl_Tar_ind)~=1
        ctrl_Tar_ind=select_ctrl_GUI('Target Control',TarName_list,'What target do you want to use as a control?');
    else
        tempind=find(validtempctrl_Tar_ind==1);
        ctrl_Tar_ind=tempctrl_Tar_ind(tempind);
    end
else
    ctrl_Tar_ind=findchareq(ctrl_Tar,TarName_list);
end
noRT_Samp_ind=findchareq('no RT',SampName_list);
if noRT_Samp_ind>length(SampName_list)
   noRT_Samp_ind=findchareq('noRT',SampName_list); 
end

[size_mat(1),size_mat(2),size_mat(3)]=size(Ct_samp_by_tar);
dCt_samp_by_tar=NaN(size_mat(1)-1,size_mat(2)-1,size_mat(3));
firsttime=true; newTarName_inds=[]; %makes new Target Name list minus the control
newSampName_inds=[];
for a=1:size_mat(1)
    if a==noRT_Samp_ind
    else
        newSampName_inds=[newSampName_inds,a];
        if a>noRT_Samp_ind
            aa=a-1;
        else
            aa=a;
        end
        for b=1:size_mat(2)
            if length(ctrl_Tar_ind)==1
                if b<ctrl_Tar_ind
                    dCt_samp_by_tar(aa,b,:)=Ct_samp_by_tar(a,ctrl_Tar_ind,:)-Ct_samp_by_tar(a,b,:);
                    if firsttime
                        newTarName_inds=[newTarName_inds,b];
                    end
                elseif b>ctrl_Tar_ind
                    dCt_samp_by_tar(aa,b-1,:)=Ct_samp_by_tar(a,ctrl_Tar_ind,:)-Ct_samp_by_tar(a,b,:);
                    if firsttime
                        newTarName_inds=[newTarName_inds,b];
                    end
                end
            else
                dCt_samp_by_tar(aa,b,:)=mean(Ct_samp_by_tar(a,ctrl_Tar_ind,:),2)-Ct_samp_by_tar(a,b,:);
                if firsttime
                    newTarName_inds=[newTarName_inds,b];
                end
            end
        end
        if firsttime
            firsttime=false;
        end
    end
end

newTarName_list=TarName_list(newTarName_inds);
newSampName_list=SampName_list(newSampName_inds);
if UI_later
    ctrl_Samp_ind=select_ctrl_GUI('Sample Control',newSampName_list,'What sample do you want to use as a control?');
else
    ctrl_Samp_ind=findchareq(ctrl_Samp,newSampName_list);
end
dFold_samp_by_tar=2.^dCt_samp_by_tar;

%% norm to E-cad option - only if ran once (and saved) normally (i.e. without this)
normed_ecad=false;
if ~savelater
    ecad_newTar_ind=findchareq('e-cad',newTarName_list);
    if ecad_newTar_ind<=length(newTarName_list)
        temp_bttn = questdlg('Do you want to normalize to E-cadherin?','Norm to E-cad','Yes','No','No');
    else
        temp_bttn = 'No';
    end
    if strcmp(temp_bttn,'Yes')
        [newsize_mat(1),newsize_mat(2),newsize_mat(3)]=size(dFold_samp_by_tar);
        new_dFold_samp_by_tar=zeros(newsize_mat(1),newsize_mat(2),newsize_mat(3));
        for a=1:newsize_mat(1)
            for b=1:newsize_mat(2)
                if b==ecad_newTar_ind %keeps old E-cad so you can see comparison if you want
                    new_dFold_samp_by_tar(a,b,:)=dFold_samp_by_tar(a,b,:);
                else
                    new_dFold_samp_by_tar(a,b,:)=dFold_samp_by_tar(a,b,:)./dFold_samp_by_tar(a,ctrl_Tar_ind,:);
                end
            end
        end
        normed_ecad=true;
        old_dFold_samp_by_tar=dFold_samp_by_tar;
        dFold_samp_by_tar = new_dFold_samp_by_tar;
        savelater=false;
    end
end
%%



mean_dFold_samp_by_tar=meanNaN3(dFold_samp_by_tar);
sd_dFold_samp_by_tar=stdNaN3(dFold_samp_by_tar);
if length(ctrl_Samp_ind)==1
    mean_ddFold_samp_by_tar=zeros(size_mat(1)-1,size_mat(2)-1);
    sd_ddFold_samp_by_tar=zeros(size_mat(1)-1,size_mat(2)-1);
else
    mean_ddFold_samp_by_tar=zeros(size_mat(1)-1,size_mat(2));
    sd_ddFold_samp_by_tar=zeros(size_mat(1)-1,size_mat(2));
end
for m=1:size(dFold_samp_by_tar,1)
    mean_ddFold_samp_by_tar(m,:)=mean_dFold_samp_by_tar(m,:)./mean(mean_dFold_samp_by_tar(ctrl_Samp_ind,:),1);
    sd_ddFold_samp_by_tar(m,:)=sd_dFold_samp_by_tar(m,:)./mean(mean_dFold_samp_by_tar(ctrl_Samp_ind,:),1);
end

package.SampleNames=newSampName_list;
package.TargetNames=newTarName_list;
package.mean=mean_ddFold_samp_by_tar;
package.sd=sd_ddFold_samp_by_tar;
if savelater
    package.raw=raw;
end
%
samp_listlen=max(size(newSampName_list));
tar_listlen=max(size(newTarName_list));
temp_cp=cell(samp_listlen*2+3,tar_listlen+1);
temp_cp(2:samp_listlen+1,1)=newSampName_list;
temp_cp(4+samp_listlen:(3+2*samp_listlen),1)=newSampName_list;
temp_cp(1,2:tar_listlen+1)=newTarName_list';
temp_cp(3+samp_listlen,2:tar_listlen+1)=newTarName_list';
meancell=cell(samp_listlen,tar_listlen);
sdcell=meancell;
for m=1:samp_listlen
    for n=1:tar_listlen
        meancell{m,n}=mean_ddFold_samp_by_tar(m,n);
        sdcell{m,n}=sd_ddFold_samp_by_tar(m,n);
    end
end
temp_cp(2:samp_listlen+1,2:tar_listlen+1)=meancell;
temp_cp(4+samp_listlen:(3+2*samp_listlen),2:tar_listlen+1)=sdcell;
temp_cp{1,1}='mean';
temp_cp{3+samp_listlen,1}='std-dev';
package.copy2excel=temp_cp;
%}

if savelater
    save(filename2save,'package')
end

%%
if display_Ct
    mean_dCt_samp_by_tar=meanNaN3(dCt_samp_by_tar);
    sd_ddCt_samp_by_tar=stdNaN3(dCt_samp_by_tar);
    for m=1:size(dCt_samp_by_tar,1)
        mean_ddCt_samp_by_tar(m,:)=mean_dCt_samp_by_tar(m,:)-mean_dCt_samp_by_tar(ctrl_Samp_ind,:);
    end

    package.mean=mean_ddCt_samp_by_tar;
    package.sd=sd_ddCt_samp_by_tar;
end

draw_qpcr_barwitherr(package,display_Ct,normed_ecad)

end


function rn = check_range_row(c)
k=1;
while true %for k=2:size(c,1)
   if isa(c{k,1},'double')
       if c{k,1}==1
           b=k;
           break
       end
   end
   k=k+1;
end
while true %for k=2:size(c,1)
   if isnan(c{k,1})
       break
   end
   k=k+1;
end
rn=[b:k-1];
end

function ind = findchareq(one,uq_list)
found=false;
for ind=1:max(size(uq_list))
    if strcmpi(one,uq_list{ind})
        found=true;
        break
    end
end
if ~found
    ind=ind+1;
end
end

function out = meanNaN3(in)
%assume dim>2
out=zeros(size(in,1),size(in,2));
for a=1:size(in,1)
    for b=1:size(in,2)
        tempdat=[];
        for c=1:size(in,3)
            if ~isnan(in(a,b,c))
                tempdat=[tempdat,in(a,b,c)];
            end                
        end
        out(a,b)=mean(tempdat);
    end
end
end
 
function out = stdNaN3(in)
%assume dim>2
out=zeros(size(in,1),size(in,2));
for a=1:size(in,1)
    for b=1:size(in,2)
        tempdat=[];
        for c=1:size(in,3)
            if ~isnan(in(a,b,c))
                tempdat=[tempdat,in(a,b,c)];
            end                
        end
        out(a,b)=std(tempdat);
    end
end
end

function whichone = select_ctrl_GUI(gui_title,list,questionprompt)
if nargin<1 || isempty(gui_title)
    gui_title = '';
end
if nargin<2 || isempty(questionprompt)
    questionprompt = 'What Color Would You Like To Use?';
end

[whichone,ok]=listdlg('ListString',list,'PromptString',questionprompt,'Name',gui_title,'SelectionMode','multiple');

if ~ok
    whichone=1;
end

end
